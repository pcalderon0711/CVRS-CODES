function v = myTrans(t,t1,restval,exval)

if t<t1
    v=restval;
else
    v=exval;

end

