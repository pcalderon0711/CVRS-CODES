function y = myLongSquare(t,restval,exerval)

if ((0<=t)&&(t<4)) || ((6<=t)&&(t<=10))
    y = exerval;
else
    y = restval;
end

