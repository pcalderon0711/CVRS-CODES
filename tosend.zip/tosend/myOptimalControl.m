%function [x,fval,exitflag,output] = myOptimalControl()

x1 = myLoader('equilibrium_rest.txt','i');
xN = myLoader('equilibrium_exer.txt','i');
params = myLoader('parameters_exer.txt','p');

N = 20;
alpha = 0;
beta = 0;

T = 10;
h = T/N;
t = linspace(0,T,N+1);

w1 = 0.01;
w2 = 0.01;
R = diag([w1,w2]);
Q = zeros(14,14);
Q(10,10) = 1;
B = zeros(14,2);
B(10,1) = 1;
B(14,2) = 1;

x_nom = zeros(14,1);
x_nom(10) = 40;

ti = 0; % ignore
f = @(x,u)(myModelWithControl(ti,x,u,params));
jacobian = @(x)(myDerivatives(x,params));

J = @(z)myCost(z, f, jacobian, B, R, Q, h, x1, x_nom);
%z0 = rand(2*N,14);
z0 = [repmat(x1',N,1); repmat((Q*(x1-x_nom))',N,1)];

options = optimset('PlotFcns',@optimplotfval,'MaxFunEvals',10000*2*14*N,'MaxIter',1000*2*14*N);
[z,fval,exitflag,output] = fminunc(J,z0,options);
x = [x1,z(1:N,:)']; % each column is one time step
p = [z(N+1:2*N,:)',Q*(x(:,N+1)-x_nom)]; % each column is one time step
u = -pinv(R)*B'*p;

save(sprintf('control(N%f,a%f,b%f).mat',N,alpha,beta),'t','x','p','u','fval','exitflag','output');
J = myCostChecker(z, f, jacobian, B, R, Q, h, x1, x_nom);